# Load required libraries
library(caret)
library(e1071)
library(randomForest)

# Assuming your dataset is named 'data'
# Assuming the target column is named 'X.drinks' and the features are named 'X.mcv.', 'X.selector.', 'X.alkphos.', 'X.sgpt.', 'X.sgot.', and 'X.gammagt.'

# Set the working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

# Load the data
data <- read.csv("liverdisorder.csv")

# Create the data partition for cross-validation
set.seed(123)
folds <- createFolds(data$X.drinks, k = 10)

# Initialize vectors to store results
linear_reg_results <- numeric()
rf_reg_results <- numeric()
svr_results <- numeric()
linear_reg_results2 <- numeric()

# Perform 10-fold cross-validation
for (i in 1:10) {
  # Split data into training and test sets
  train_data <- data[-folds[[i]], ]
  test_data <- data[folds[[i]], ]
  
  # Linear regression
  linear_reg_model <- lm(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., data = train_data)
  linear_reg_pred <- predict(linear_reg_model, newdata = test_data)
  linear_reg_results <- c(linear_reg_results, sqrt(mean((test_data$X.drinks - linear_reg_pred)^2)))
  
  # Random forest regression
  rf_reg_model <- randomForest(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., data = train_data)
  rf_reg_pred <- predict(rf_reg_model, newdata = test_data)
  rf_reg_results <- c(rf_reg_results, sqrt(mean((test_data$X.drinks - rf_reg_pred)^2)))
  
  # Support vector regression
  svr_model <- svm(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., data = train_data)
  svr_pred <- predict(svr_model, newdata = test_data)
  svr_results <- c(svr_results, sqrt(mean((test_data$X.drinks - svr_pred)^2)))
}

# Print the mean RMSE for each model
print(paste("Linear Regression RMSE:", mean(linear_reg_results)))
print(paste("Random Forest Regression RMSE:", mean(rf_reg_results)))
print(paste("Support Vector Regression RMSE:", mean(svr_results)))

glm.fit=glm(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., data = train_data)
summary(glm.fit)

# Perform 10-fold cross-validation
for (i in 1:10) {
  # Split data into training and test sets
  train_data <- data[-folds[[i]], ]
  test_data <- data[folds[[i]], ]
  
  # Linear regression
  linear_reg_model2 <- lm(X.drinks. ~  X.mcv. + X.gammagt., data = train_data)
  linear_reg_pred2 <- predict(linear_reg_model2, newdata = test_data)
  linear_reg_results2 <- c(linear_reg_results2, sqrt(mean((test_data$X.drinks - linear_reg_pred2)^2)))
}

# Print the mean RMSE for each model
print(paste("Linear Regression RMSE:", mean(linear_reg_results)))
print(paste("Random Forest Regression RMSE:", mean(rf_reg_results)))
print(paste("Support Vector Regression RMSE:", mean(svr_results)))
print(paste("Linear Regression RMSE v2:", mean(linear_reg_results2)))

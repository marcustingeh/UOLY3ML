library(rpart)

#set working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

#load data
data <- read.csv("php0iVrYT.csv")

tree_model <- rpart(Class ~ ., data = data, method = "class")

# Print the decision tree
print(tree_model)

# Make predictions
predictions <- predict(tree_model, data, type = "class")

# Evaluate the model (you can use a confusion matrix or other metrics)
confusion_matrix <- table(data$Class, predictions)
print(confusion_matrix)


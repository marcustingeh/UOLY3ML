#set working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

#load data
data <- read.csv("php0iVrYT.csv")

# Load the xgboost package
library(xgboost)

# Split the data into training and testing sets
set.seed(123) # for reproducibility
train_index <- sample(1:nrow(data), 0.7*nrow(data))
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

# Convert data to matrix format
train_matrix <- as.matrix(train_data[, -which(names(train_data) == "Class")])
test_matrix <- as.matrix(test_data[, -which(names(test_data) == "Class")])

# Extract labels
train_label <- train_data$Class - 1
test_label <- test_data$Class -1 


# Train the model
xgb_model <- xgboost(data = train_matrix, 
                     label = train_label, 
                     nrounds = 100, 
                     objective = "binary:logistic",
                     eval_metric = "error",
                     verbose = 0)

# Make predictions on the test set
pred <- predict(xgb_model, test_matrix)

# Convert predicted probabilities to class labels
pred_class <- ifelse(pred > 0.5, 2, 1)

# Evaluate the model
accuracy <- mean(pred_class == test_label)
print(paste("Accuracy:", accuracy))

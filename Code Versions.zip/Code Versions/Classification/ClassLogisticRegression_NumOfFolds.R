# Load the caret package
library(caret)

# Set the working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

# Load the data
my_data <- read.csv("php0iVrYT.csv")

# Convert the 'class' column to a factor
my_data$Class <- as.factor(my_data$Class)

# Create a vector to store the results
results <- numeric(0)

# Loop through different number of folds
for (i in 3:15) {
  # Define the training control for k-fold cross-validation
  trainControl <- trainControl(method = "cv", number = i)
  
  # Train a logistic regression model using k-fold cross-validation
  model <- train(Class ~ V1 + V2 + V3 + V4, data = my_data, method = "glm", family = "binomial", trControl = trainControl)
  
  # Store the results (e.g., accuracy)
  results[i - 2] <- model$results$Accuracy
}

# Plot the results
plot(3:15, results, type = "b", xlab = "Number of Folds", ylab = "Accuracy", main = "Accuracy vs. Number of Folds")

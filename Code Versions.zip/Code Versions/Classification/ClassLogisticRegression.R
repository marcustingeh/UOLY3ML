# Load the caret package
library(caret)

# Load the ROCR package for ROC curve
library(ROCR)

# Set the working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

# Load the data
my_data <- read.csv("php0iVrYT.csv")

# Convert the 'class' column to a factor
my_data$Class <- as.factor(my_data$Class)

# Split the data into training and testing sets
set.seed(123) # For reproducibility
trainIndex <- sample(1:nrow(my_data), 0.7*nrow(my_data))
trainData <- my_data[trainIndex, ]
testData <- my_data[-trainIndex, ]

# Define the training control for 5-fold cross-validation
trainControl <- trainControl(method = "cv", number = 10)

# Train a logistic regression model using k-fold cross-validation
model <- train(Class ~ V1 + V2 + V3 + V4, data = my_data, method = "glm", family = "binomial", trControl = trainControl)

# Make predictions on the test set
predictions <- predict(model, newdata = testData)

# Evaluate the model
confusionMatrix(predictions, testData$Class)

# Calculate the ROC curve
roc_pred <- prediction(predictions, testData$Class)
roc_perf <- performance(roc_pred, "tpr", "fpr")

# Plot the ROC curve
plot(roc_perf, col = "blue", lwd = 2, main = "ROC Curve")
abline(a = 0, b = 1, lty = 2, col = "gray")

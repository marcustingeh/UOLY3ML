# Set the working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

# Load the data
data <- read.csv("php0iVrYT.csv")
# Check for missing values
if (any(is.na(data))) {
  data <- na.omit(data)
}

# Assuming your dataset is stored in a variable called 'data'
# Preprocess the data if needed (e.g., scaling)
scaled_data <- scale(data)

# Perform K-means clustering with varying numbers of clusters (e.g., 1 to 10)
k_values <- 1:10
ssd <- numeric(length(k_values))

for (k in k_values) {
  kmeans_model <- kmeans(scaled_data, centers = k, nstart = 10)
  ssd[k] <- kmeans_model$tot.withinss
}

# Find the "elbow" point
diff_ss <- diff(ssd)
# Find the "elbow" point
elbow_point <- which(diff(diff_ss) < 0)[1] + 1
if (is.na(elbow_point)) {
  # If elbow_point is NA, find the next best value
  elbow_point <- which(diff(diff_ss) < 0)[2] + 1
}

# Plot the sum of squared distances against the number of clusters
plot(k_values, ssd, type = "b", xlab = "Number of Clusters", ylab = "Sum of Squared Distances", main = "Elbow Method for Optimal K")
abline(v = elbow_point, col = "red", lty = 2)

# Perform K-means clustering with the optimal number of clusters
kmeans_model <- kmeans(scaled_data, centers = elbow_point, nstart = 10)

# Get cluster assignments for each data point
cluster_assignments <- kmeans_model$cluster

# Assuming 'scaled_data' is your scaled dataset and 'cluster_assignments' are your cluster assignments
# Convert cluster assignments to a factor for plotting
cluster_factor <- as.factor(cluster_assignments)

# Perform PCA
pca_result <- prcomp(scaled_data, scale. = TRUE)
pca_data <- as.data.frame(pca_result$x[, 1:2])  # Use the first two principal components for 2D visualization

# Perform t-SNE
library(Rtsne)
scaled_data <- unique(scaled_data)

tsne_result <- Rtsne(scaled_data, dims = 2, perplexity = 30, verbose = TRUE)

# Plot the results
plot(pca_data[,1], pca_data[,2], pch = 19, col = cluster_factor, main = "PCA Visualization",xlab = "Principal Component 1", ylab = "Principal Component 2")
plot(tsne_result$Y, pch = 19, col = cluster_factor, main = "t-SNE Visualization")

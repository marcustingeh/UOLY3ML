# Load required libraries
library(caret)
library(randomForest)

# Assuming your dataset is named 'data'
# Assuming the target column is named 'X.drinks' and the features are named 'X.mcv.', 'X.selector.', 'X.alkphos.', 'X.sgpt.', 'X.sgot.', and 'X.gammagt.'

# Set the working directory
setwd("C:/Users/xavie/OneDrive/Desktop/MLCW/Data")

# Load the data
data <- read.csv("liverdisorder.csv")

# Create the data partition for cross-validation
set.seed(123)
folds <- createFolds(data$X.drinks, k = 10)

# Initialize vector to store results
rf_reg_results <- numeric()

# Initialize the range of number of trees to evaluate
num_trees <- seq(50, 500, by = 50)

# Initialize a vector to store RMSE values for each number of trees
rmse_values <- numeric(length(num_trees))

# Perform 10-fold cross-validation for each number of trees
for (i in 1:length(num_trees)) {
  for (j in 1:10) {
    # Split data into training and test sets
    train_data <- data[-folds[[j]], ]
    test_data <- data[folds[[j]], ]
    
    # Random forest regression
    rf_reg_model <- randomForest(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., 
                                 data = train_data, ntree = num_trees[i])
    rf_reg_pred <- predict(rf_reg_model, newdata = test_data)
    rmse_values[i] <- rmse_values[i] + sqrt(mean((test_data$X.drinks - rf_reg_pred)^2))
  }
  # Average RMSE across folds
  rmse_values[i] <- rmse_values[i] / 10
}

# Find the optimal number of trees based on RMSE
optimal_num_trees <- num_trees[which.min(rmse_values)]

# Train the final model with the optimal number of trees
final_rf_model <- randomForest(X.drinks. ~ X.mcv. + X.selector. + X.alkphos. + X.sgpt. + X.sgot. + X.gammagt., 
                               data = data, ntree = optimal_num_trees)

# Make predictions on the entire dataset
final_rf_pred <- predict(final_rf_model, newdata = data)

# Calculate the RMSE for the final model
final_rf_rmse <- sqrt(mean((data$X.drinks. - final_rf_pred)^2))

# Print the optimal number of trees and the RMSE for the final model
print(paste("Optimal Number of Trees:", optimal_num_trees))
print(paste("Final Random Forest Regression RMSE:", final_rf_rmse))

# Plot RMSE vs. number of trees
plot(num_trees, rmse_values, type = "b", xlab = "Number of Trees", ylab = "RMSE")
abline(v = optimal_num_trees, col = "red", lty = 2)
